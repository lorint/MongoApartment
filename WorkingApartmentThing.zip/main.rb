require 'pry'
#require 'rainbow'
require 'mongoid'


Mongoid.load!("mongoid.yml", :development)


require_relative 'building'
require_relative 'apartment'
require_relative 'person'

building = nil

response = nil
while response != 'q'
  print "Build (p)erson or (a)partment or building or (q)uit: "
  response = gets.chomp.downcase
  if response == 'p'
    if building == nil
      print "Must build a building first!\n"
      next
    end
    print "Name: "
    name = gets.chomp
    print "Age: "
    age = gets.to_i
    print "Gender: "
    gender = gets.chomp
    print "What apt do you wish to live: "
    apt = gets.chomp
    building.apartments[apt].renters << Person.new(name, age, gender)
  elsif response == 'a'
    if building == nil
      print "Must build a building first!\n"
      next
    end
    print "Name: "
    name = gets.chomp
    print "SqFt: "
    sqft = gets.to_i
    building.apartments[name] = Apartment.new(name, sqft, 0, 0)
  elsif response == 'b'
    print "Address: "
    address = gets.chomp
    print "Style: "
    style = gets.chomp
    print "Num Floors: "
    num_floors = gets.to_i
    building = Building.create(address: address, style: style, num_floors: num_floors)
    building.save
  end
end

#binding.pry